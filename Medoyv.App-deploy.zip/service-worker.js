const CACHE_NAME = "med-app-v2";
const APP_SHELL = [
  "./",
  "./index.html",
  "./styles.css",
  "./apps.js",
  "./manifest.webmanifest",
  "./favicon.svg",
  "./assets/brand/icon-192.png",
  "./assets/brand/icon-512.png",
  "./assets/brand/apple-touch-icon.png",
  "./assets/apps/avito.png",
  "./assets/apps/vk-video.png",
  "./assets/apps/vkontakte.png",
  "./assets/apps/mail.png",
  "./assets/apps/rshb.png",
  "./assets/apps/sbpay.png",
  "./assets/apps/sovcombank.png",
  "./assets/apps/yandex-pay.png",
  "./assets/apps/happ-vpn.png",
  "./assets/apps/max.png",
  "./assets/apps/online.png",
  "./assets/apps/ozon-bank.png",
  "./assets/apps/t-start.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith("medoyv-app-") && key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          const responsePath = response.url ? new URL(response.url).pathname : "";
          if (response.ok && !response.redirected && responsePath !== "/login") {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put("./index.html", copy));
          }
          return response;
        })
        .catch(() => caches.match("./index.html"))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
