const filters = [
  { id: "all", label: "Все" }, { id: "finance", label: "Финансы" },
  { id: "social", label: "Социальные" }, { id: "communication", label: "Связь" },
  { id: "services", label: "Сервисы" }, { id: "tools", label: "Инструменты" },
];

const apps = [
  { name: "ВКонтакте", version: "8.183", category: "social", categoryLabel: "Социальные", asset: "vkontakte.png", manifestUrl: "" },
  { name: "ВК Видео", version: "8.183", category: "social", categoryLabel: "Видео", asset: "vk-video.png", manifestUrl: "" },
  { name: "MAX", version: "26.17.3", category: "communication", categoryLabel: "Связь", asset: "max.png", manifestUrl: "" },
  { name: "Почта Mail", version: "Версия не указана", category: "communication", categoryLabel: "Почта", asset: "mail.png", manifestUrl: "" },
  { name: "Россельхоз Банк", version: "Версия не указана", category: "finance", categoryLabel: "Банк", asset: "rshb.png", manifestUrl: "" },
  { name: "СБПэй", version: "1.11.8", category: "finance", categoryLabel: "Оплата", asset: "sbpay.png", manifestUrl: "" },
  { name: "Совкомбанк", version: "Версия не указана", category: "finance", categoryLabel: "Банк", asset: "sovcombank.png", manifestUrl: "" },
  { name: "Яндекс Пей (Банк)", version: "Версия не указана", category: "finance", categoryLabel: "Банк", asset: "yandex-pay.png", manifestUrl: "" },
  { name: "Online", version: "17.0.0", category: "finance", categoryLabel: "Банк", asset: "online.png", manifestUrl: "" },
  { name: "Ozon Банк", version: "19.27.0", category: "finance", categoryLabel: "Банк", asset: "ozon-bank.png", manifestUrl: "" },
  { name: "T-Start (Тинькофф)", version: "6.35.1", category: "finance", categoryLabel: "Банк", asset: "t-start.png", manifestUrl: "" },
  { name: "Авито", version: "Версия не указана", category: "services", categoryLabel: "Сервисы", asset: "avito.png", manifestUrl: "" },
  { name: "Happ+ (VPN)", version: "Версия не указана", category: "tools", categoryLabel: "Инструменты", asset: "happ-vpn.png", manifestUrl: "" },
];

const grid = document.querySelector("#app-grid");
const filterList = document.querySelector("#filter-list");
const searchInput = document.querySelector("#search-input");
const resultCount = document.querySelector("#result-count");
const emptyState = document.querySelector("#empty-state");
const installDialog = document.querySelector("#install-dialog");
const offlineStatus = document.querySelector("#offline-status");
let selectedFilter = "all";
let query = "";

function installLink(app) {
  if (!app.manifestUrl) return "";
  return "itms-services://?action=download-manifest&url=" + encodeURIComponent(app.manifestUrl);
}

function renderFilters() {
  filterList.innerHTML = filters.map((filter) =>
    '<button class="filter-button' + (filter.id === selectedFilter ? " active" : "") +
    '" type="button" data-filter="' + filter.id + '" aria-pressed="' +
    (filter.id === selectedFilter) + '">' + filter.label + "</button>"
  ).join("");
}

function renderApps() {
  const visibleApps = apps.filter((app) => {
    const matchesFilter = selectedFilter === "all" || app.category === selectedFilter;
    const matchesQuery = (app.name + " " + app.categoryLabel).toLocaleLowerCase("ru").includes(query);
    return matchesFilter && matchesQuery;
  });

  resultCount.textContent = visibleApps.length + " из " + apps.length;
  emptyState.hidden = visibleApps.length !== 0;
  grid.hidden = visibleApps.length === 0;
  grid.innerHTML = visibleApps.map((app) => {
    const link = installLink(app);
    const action = link
      ? '<a class="install-button ready" href="' + link + '">Установить <span aria-hidden="true">↓</span></a>'
      : '<button class="install-button" type="button" disabled title="Для установки нужна разрешённая подписанная сборка и манифест размещения">Нужна подпись издателя</button>';
    return '<article class="app-card">' +
      '<div class="card-top"><div class="app-icon"><img src="./assets/apps/' + app.asset + '" alt="" loading="lazy"></div><span class="category-tag">' + app.categoryLabel + '</span></div>' +
      '<h3 title="' + app.name + '">' + app.name + '</h3>' +
      '<p class="app-version">Версия ' + app.version + '</p><div class="card-rule"></div>' +
      '<p class="app-status"><span class="status-dot"></span> Ожидает настройки установки</p>' + action + '</article>';
  }).join("");
}

renderFilters();
renderApps();
document.querySelector("#hero-count").textContent = apps.length;

filterList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-filter]");
  if (!button) return;
  selectedFilter = button.dataset.filter;
  renderFilters();
  renderApps();
});

searchInput.addEventListener("input", () => {
  query = searchInput.value.trim().toLocaleLowerCase("ru");
  renderApps();
});

document.querySelectorAll("#show-install").forEach((button) => {
  button.addEventListener("click", () => installDialog.showModal());
});
installDialog.querySelector(".dialog-close").addEventListener("click", () => installDialog.close());
installDialog.addEventListener("click", (event) => {
  if (event.target === installDialog) installDialog.close();
});

function setOfflineStatus() {
  if (offlineStatus) offlineStatus.innerHTML = navigator.onLine
    ? '<span class="status-dot ready-dot"></span> Каталог сохранится для офлайн-доступа'
    : '<span class="status-dot offline-dot"></span> Офлайн-режим';
}
window.addEventListener("online", setOfflineStatus);
window.addEventListener("offline", setOfflineStatus);
setOfflineStatus();

if ("serviceWorker" in navigator && location.protocol !== "file:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js")
      .then(() => navigator.serviceWorker.ready)
      .then(() => {
        if (offlineStatus) offlineStatus.innerHTML = '<span class="status-dot ready-dot"></span> Офлайн-каталог готов';
      })
      .catch(() => {
        if (offlineStatus) offlineStatus.innerHTML = '<span class="status-dot"></span> Для офлайн-режима нужен HTTPS';
      });
  });
}
