"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");

const PORT = Number(process.env.PORT || 3000);
const SITE_PASSWORD = process.env.SITE_PASSWORD || "";
const SESSION_SECONDS = 30 * 24 * 60 * 60;
const ROOT = path.resolve(__dirname);
const LOGIN_HTML = `<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f6f7fb"><title>Вход — Medoyv.App</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;min-height:100svh;display:grid;place-items:center;padding:24px;background:#f6f7fb;color:#192139;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.panel{width:min(100%,420px);padding:36px 30px 30px;background:#fff;border:1px solid #e5e9f2;border-radius:24px;box-shadow:0 24px 64px #1b315012}.brand{display:flex;align-items:center;gap:12px;font-size:19px;font-weight:750;letter-spacing:-.04em}.mark{width:36px;height:36px;border-radius:12px;background:linear-gradient(145deg,#326bff,#7c59f6);display:grid;grid-template-columns:repeat(2,7px);grid-template-rows:repeat(2,7px);gap:4px;place-content:center}.mark i{background:#fff;border-radius:2px}h1{margin:30px 0 8px;font-size:28px;letter-spacing:-.05em}p{margin:0 0 24px;color:#69738a;line-height:1.5}label{display:block;margin-bottom:8px;font-size:13px;font-weight:650}input{width:100%;height:50px;border:1px solid #dce2ed;border-radius:12px;padding:0 14px;font:inherit;outline:none}input:focus{border-color:#5079f5;box-shadow:0 0 0 3px #5079f51a}button{width:100%;height:50px;margin-top:14px;border:0;border-radius:12px;background:#356af4;color:white;font:inherit;font-weight:700;cursor:pointer}button:active{transform:translateY(1px)}.error{margin-top:14px;color:#b42332;font-size:14px}.hint{margin-top:22px!important;margin-bottom:0!important;font-size:12px}
</style></head><body><main class="panel"><div class="brand"><span class="mark" aria-hidden="true"><i></i><i></i><i></i><i></i></span>Medoyv.App</div><h1>Закрытый каталог</h1><p>Введите код доступа, который вам передал владелец сайта.</p><form action="/login" method="post"><label for="password">Код доступа</label><input id="password" name="password" type="password" autocomplete="current-password" required autofocus><button type="submit">Войти</button>${"{{ERROR}}"}</form><p class="hint">Пароль вводится только для доступа к каталогу.</p></main></body></html>`;

if (SITE_PASSWORD.length < 12) {
  console.error("Set SITE_PASSWORD to a secret of at least 12 characters before starting the server.");
  process.exit(1);
}

const failedAttempts = new Map();

function send(res, status, body, contentType = "text/plain; charset=utf-8", extraHeaders = {}) {
  res.writeHead(status, {
    "Content-Type": contentType,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    ...extraHeaders
  });
  res.end(body);
}

function redirect(res, location, extraHeaders = {}) {
  res.writeHead(303, { Location: location, "Cache-Control": "no-store", ...extraHeaders });
  res.end();
}

function sessionCookie(expiresAt) {
  const payload = String(expiresAt);
  const signature = crypto.createHmac("sha256", SITE_PASSWORD).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function isAuthenticated(req) {
  const cookies = (req.headers.cookie || "").split(";");
  const item = cookies.map((part) => part.trim()).find((part) => part.startsWith("medoyv_session="));
  if (!item) return false;

  const token = item.slice("medoyv_session=".length);
  const separator = token.indexOf(".");
  if (separator < 1) return false;
  const payload = token.slice(0, separator);
  const providedSignature = Buffer.from(token.slice(separator + 1));
  const expiresAt = Number(payload);
  if (!Number.isSafeInteger(expiresAt) || expiresAt <= Math.floor(Date.now() / 1000)) return false;

  const expectedSignature = Buffer.from(crypto.createHmac("sha256", SITE_PASSWORD).update(payload).digest("base64url"));
  return providedSignature.length === expectedSignature.length && crypto.timingSafeEqual(providedSignature, expectedSignature);
}

function readForm(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 8192) {
        reject(new Error("Form too large"));
        req.destroy();
      }
    });
    req.on("end", () => resolve(new URLSearchParams(body)));
    req.on("error", reject);
  });
}

function sameSecret(input) {
  const supplied = Buffer.from(input);
  const expected = Buffer.from(SITE_PASSWORD);
  return supplied.length === expected.length && crypto.timingSafeEqual(supplied, expected);
}

function rateLimit(req) {
  const key = req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const current = failedAttempts.get(key);
  if (current && current.resetAt > now && current.count >= 8) return { limited: true, key };
  if (!current || current.resetAt <= now) failedAttempts.set(key, { count: 0, resetAt: now + 15 * 60 * 1000 });
  return { limited: false, key };
}

function mimeType(filePath) {
  switch (path.extname(filePath).toLowerCase()) {
    case ".html": return "text/html; charset=utf-8";
    case ".css": return "text/css; charset=utf-8";
    case ".js": return "text/javascript; charset=utf-8";
    case ".json": return "application/json; charset=utf-8";
    case ".webmanifest": return "application/manifest+json; charset=utf-8";
    case ".svg": return "image/svg+xml";
    case ".png": return "image/png";
    case ".ico": return "image/x-icon";
    default: return "application/octet-stream";
  }
}

async function serveFile(req, res, pathname) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch {
    return send(res, 400, "Bad request");
  }
  if (decoded.includes("\\") || decoded.includes("\0")) return send(res, 400, "Bad request");

  const relative = decoded === "/" ? "index.html" : decoded.replace(/^\/+/, "");
  const filePath = path.resolve(ROOT, relative);
  if (filePath !== ROOT && !filePath.startsWith(ROOT + path.sep)) return send(res, 404, "Not found");

  let stat;
  try {
    stat = await fs.promises.stat(filePath);
  } catch {
    return send(res, 404, "Not found");
  }
  if (!stat.isFile()) return send(res, 404, "Not found");

  const cacheControl = path.basename(filePath) === "service-worker.js"
    ? "no-cache"
    : path.extname(filePath) === ".html" || path.extname(filePath) === ".js" || path.extname(filePath) === ".css"
      ? "no-cache"
      : "public, max-age=3600";
  res.writeHead(200, {
    "Content-Type": mimeType(filePath),
    "Content-Length": stat.size,
    "Cache-Control": cacheControl,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()"
  });
  if (req.method === "HEAD") return res.end();
  fs.createReadStream(filePath).pipe(res);
}

const server = http.createServer(async (req, res) => {
  let requestUrl;
  try {
    requestUrl = new URL(req.url, "http://localhost");
  } catch {
    return send(res, 400, "Bad request");
  }
  const pathname = requestUrl.pathname;

  if (pathname === "/healthz") return send(res, 200, "ok", "text/plain; charset=utf-8", { "Cache-Control": "no-store" });
  if (req.method === "GET" && pathname === "/login") {
    return send(res, 200, LOGIN_HTML.replace("{{ERROR}}", ""), "text/html; charset=utf-8", { "Cache-Control": "no-store" });
  }

  if (req.method === "POST" && pathname === "/login") {
    const limit = rateLimit(req);
    if (limit.limited) return send(res, 429, LOGIN_HTML.replace("{{ERROR}}", '<p class="error">Слишком много попыток. Подождите 15 минут.</p>'), "text/html; charset=utf-8", { "Cache-Control": "no-store", "Retry-After": "900" });
    let form;
    try {
      form = await readForm(req);
    } catch {
      return send(res, 400, "Bad request");
    }
    if (!sameSecret(form.get("password") || "")) {
      const current = failedAttempts.get(limit.key);
      failedAttempts.set(limit.key, { count: (current?.count || 0) + 1, resetAt: current?.resetAt || Date.now() + 15 * 60 * 1000 });
      return send(res, 401, LOGIN_HTML.replace("{{ERROR}}", '<p class="error">Неверный код доступа. Попробуйте ещё раз.</p>'), "text/html; charset=utf-8", { "Cache-Control": "no-store" });
    }
    failedAttempts.delete(limit.key);
    const expiresAt = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
    return redirect(res, "/", { "Set-Cookie": `medoyv_session=${sessionCookie(expiresAt)}; Path=/; Max-Age=${SESSION_SECONDS}; HttpOnly; Secure; SameSite=Lax` });
  }

  if (req.method === "GET" && pathname === "/logout") {
    return redirect(res, "/login", { "Set-Cookie": "medoyv_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax" });
  }

  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Method not allowed", "text/plain; charset=utf-8", { Allow: "GET, HEAD" });
  if (!isAuthenticated(req)) return redirect(res, "/login");
  return serveFile(req, res, pathname);
});

server.listen(PORT, "0.0.0.0", () => console.log(`Medoyv.App listening on port ${PORT}`));
